package com.assignment.tictactoe;

public class GameFacade {

	private Game game;

	public GameFacade() {
		game = new Game();
	}

	public void startGame() {
		game.start();
	}
}