package com.project.app.app;

import java.util.Scanner;

import com.project.app.service.StudentService;

public class MainApp {

	public static void main(String[] args) {

		StudentService service = new StudentService();
		Scanner sc = new Scanner(System.in);
		int choice = 0;

		System.out.println("=============================================");
		System.out.println("   STUDENT COURSE REGISTRATION SYSTEM        ");
		System.out.println("=============================================");

		do {
			printMenu();
			System.out.print("Enter choice: ");
			choice = sc.nextInt();
			sc.nextLine(); // clear buffer

			switch (choice) {

			case 1: // Add Student
				System.out.println("\n--- ADD STUDENT ---");
				System.out.print("Student ID : ");
				int id = sc.nextInt();
				sc.nextLine();
				System.out.print("Name       : ");
				String name = sc.nextLine();
				System.out.print("Age        : ");
				int age = sc.nextInt();
				sc.nextLine();
				System.out.print("Branch     : ");
				String branch = sc.nextLine();
				System.out.println(service.addStudent(id, name, age, branch));
				break;

			case 2: // Register for Course
				System.out.println("\n--- REGISTER FOR COURSE ---");
				// Show available courses FIRST so student picks from valid list
				service.showAllCourses();
				System.out.print("Student ID  : ");
				int sid = sc.nextInt();
				sc.nextLine();
				System.out.print("Course Name : ");
				String course = sc.nextLine();
				System.out.print("Fees        : ");
				double fees = sc.nextDouble();
				sc.nextLine();
				System.out.println(service.registerCourse(sid, course, fees));
				break;

			case 3: // View All Students
				service.viewAllStudentsWithCourses();
				break;

			case 4: // Search Student
				System.out.print("\nEnter Student ID: ");
				int searchId = sc.nextInt();
				sc.nextLine();
				service.searchStudentById(searchId);
				break;

			case 5: // Update Student
				System.out.println("\n--- UPDATE STUDENT ---");
				System.out.print("Student ID : ");
				int uid = sc.nextInt();
				sc.nextLine();
				System.out.print("New Name   : ");
				String nn = sc.nextLine();
				System.out.print("New Branch : ");
				String nb = sc.nextLine();
				System.out.println(service.updateStudent(uid, nn, nb));
				break;

			case 6: // Update Fee
				System.out.println("\n--- UPDATE COURSE FEE ---");
				System.out.print("Student ID  : ");
				int fid = sc.nextInt();
				sc.nextLine();
				System.out.print("Course Name : ");
				String fc = sc.nextLine();
				System.out.print("New Fee     : ");
				double nf = sc.nextDouble();
				sc.nextLine();
				System.out.println(service.updateFee(fid, fc, nf));
				break;

			case 7: // Cancel Registration
				System.out.println("\n--- CANCEL REGISTRATION ---");
				System.out.print("Student ID  : ");
				int cid = sc.nextInt();
				sc.nextLine();
				System.out.print("Course Name : ");
				String cc = sc.nextLine();
				System.out.println(service.cancelRegistration(cid, cc));
				break;

			case 8: // Delete Student
				System.out.println("\n--- DELETE STUDENT ---");
				System.out.print("Student ID  : ");
				int did = sc.nextInt();
				sc.nextLine();
				System.out.print("Confirm delete? (yes/no): ");
				if (sc.nextLine().equalsIgnoreCase("yes"))
					System.out.println(service.deleteStudent(did));
				else
					System.out.println("Delete cancelled.");
				break;

			case 9: // High Paying Students
				System.out.print("\nEnter minimum fee: ");
				double mf = sc.nextDouble();
				sc.nextLine();
				service.highPayingStudents(mf);
				break;

			case 10: // Course-wise Count
				service.courseWiseCount();
				break;

			case 11: // View All Available Courses
				service.showAllCourses();
				break;

			case 12: // Exit
				System.out.println("\nGoodbye!");
				break;

			default:
				System.out.println("Invalid choice. Enter 1-12.");
			}

		} while (choice != 12);

		sc.close();
	}

	private static void printMenu() {
		System.out.println("\n=============================================");
		System.out.println("                MAIN MENU                    ");
		System.out.println("=============================================");
		System.out.println(" 1.  Add Student");
		System.out.println(" 2.  Register for Course");
		System.out.println(" 3.  View All Students with Courses");
		System.out.println(" 4.  Search Student by ID");
		System.out.println(" 5.  Update Student");
		System.out.println(" 6.  Update Course Fee");
		System.out.println(" 7.  Cancel Registration");
		System.out.println(" 8.  Delete Student");
		System.out.println(" 9.  High Paying Students Report");
		System.out.println(" 10. Course-wise Student Count");
		System.out.println(" 11. View All Available Courses");
		System.out.println(" 12. Exit");
		System.out.println("=============================================");
	}
}